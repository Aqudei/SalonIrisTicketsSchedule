Replace SalonIrisTicketsSchedule

in 

C\program files\3da\AirportSalonSoftware